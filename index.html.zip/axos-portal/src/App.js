import { useState, useRef } from "react";
import "./styles/global.css";
import {
  LayoutDashboard, FolderOpen, UploadCloud, MessageSquare,
  Users, Clock, Bell, ChevronRight, Check, FileText,
  Shield, ExternalLink, Send, Download, Eye, X, Menu,
  TrendingUp, Activity, AlertCircle
} from "lucide-react";
import {
  TEAM, STAGES, DEALS, DEAL_HISTORY, DOCUMENTS, MESSAGES, NOTIFICATIONS
} from "./data";

// ─── HELPERS ──────────────────────────────────────────────────────────────────
function Avatar({ initials, gold, online, size }) {
  const cls = ["avatar", gold ? "avatar-gold" : "", online ? "avatar-online" : "", size === "sm" ? "avatar-sm" : size === "lg" ? "avatar-lg" : ""].filter(Boolean).join(" ");
  return <div className={cls}>{initials}</div>;
}

function Badge({ label, variant = "slate" }) {
  return <span className={`badge badge-${variant}`}>{label}</span>;
}

function statusBadge(status) {
  if (status === "Approved") return <Badge label="Approved" variant="green" />;
  if (status === "Pending Review") return <Badge label="Pending Review" variant="amber" />;
  if (status === "Under Review") return <Badge label="Under Review" variant="blue" />;
  if (status === "Closed") return <Badge label="Closed" variant="slate" />;
  if (status === "Active") return <Badge label="Active" variant="green" />;
  if (status === "Closing") return <Badge label="Closing" variant="amber" />;
  return <Badge label={status} />;
}

function priorityBadge(p) {
  if (p === "Critical") return <Badge label="Critical" variant="red" />;
  if (p === "High") return <Badge label="High" variant="amber" />;
  return <Badge label={p} variant="slate" />;
}

function Pipeline({ stageIndex }) {
  return (
    <div className="pipeline-steps">
      {STAGES.map((s, i) => {
        const cls = i < stageIndex ? "completed" : i === stageIndex ? "active" : "";
        return (
          <div key={s} className={`pipeline-step ${cls}`}>
            <div className="step-dot">
              {i < stageIndex ? <Check size={10} /> : i + 1}
            </div>
            <span className="step-label">{s}</span>
          </div>
        );
      })}
    </div>
  );
}

const TICKER_ITEMS = [
  { label: "KKR Credit Partners VII", value: "Advancing to Closing · Jun 2025" },
  { label: "Blackstone Credit Fund IV", value: "CAM Review In Progress" },
  { label: "Apollo Capital Partners VIII", value: "Term Sheet Issued" },
  { label: "Ares Management Credit Fund XI", value: "PICS Under Internal Review" },
  { label: "Blue Owl Capital Fund III", value: "Due Diligence Commenced" },
  { label: "Axos Fund Finance", value: "New York, NY · axosbank.com/Business/Fund-Finance" },
];

// ─── TICKER ───────────────────────────────────────────────────────────────────
function Ticker() {
  return (
    <div className="ticker-bar">
      <div className="ticker-inner">
        {[...TICKER_ITEMS, ...TICKER_ITEMS].map((item, i) => (
          <span key={i} className="ticker-item">
            <span className="dot" />
            <strong>{item.label}</strong>
            {item.value}
          </span>
        ))}
      </div>
    </div>
  );
}

// ─── SIDEBAR ──────────────────────────────────────────────────────────────────
const NAV = [
  { key: "dashboard",  label: "Dashboard",       icon: LayoutDashboard },
  { key: "deals",      label: "Active Deals",    icon: TrendingUp },
  { key: "documents",  label: "Document Vault",  icon: FolderOpen },
  { key: "messages",   label: "Messages",        icon: MessageSquare },
  { key: "team",       label: "Team & Contacts", icon: Users },
  { key: "history",    label: "Deal History",    icon: Clock },
  { key: "alerts",     label: "Alerts",          icon: Bell },
];

function Sidebar({ active, onNav, unread }) {
  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <a href="https://axosbank.com/Business/Fund-Finance" target="_blank" rel="noopener noreferrer">
          <div className="logo-wordmark">AXOS BANK</div>
          <div className="logo-sub">FUND FINANCE · CLIENT PORTAL</div>
        </a>
      </div>
      <nav className="sidebar-nav">
        <div className="nav-section-label">Navigation</div>
        {NAV.map(({ key, label, icon: Icon }) => (
          <div
            key={key}
            className={`nav-item${active === key ? " active" : ""}`}
            onClick={() => onNav(key)}
          >
            <Icon size={15} />
            {label}
            {key === "alerts" && unread > 0 && (
              <span className="nav-badge">{unread}</span>
            )}
          </div>
        ))}
      </nav>
      <div className="sidebar-footer">
        <div className="footer-user">
          <Avatar initials="BC" gold />
          <div>
            <div className="footer-name">Blackstone Credit</div>
            <div className="footer-role">Client Portal</div>
          </div>
        </div>
      </div>
    </aside>
  );
}

// ─── HEADER ───────────────────────────────────────────────────────────────────
function Header({ page, unread, onNav }) {
  const titles = {
    dashboard: { title: "Dashboard", sub: "Portfolio overview and deal status" },
    deals:     { title: "Active Deals", sub: "Monitor your deal pipeline" },
    documents: { title: "Document Vault", sub: "Secure document upload and tracking" },
    messages:  { title: "Messages", sub: "Direct communication with your Axos team" },
    team:      { title: "Team & Contacts", sub: "Axos Fund Finance — New York, NY" },
    history:   { title: "Deal History", sub: "Completed transactions and archive" },
    alerts:    { title: "Alerts & Notifications", sub: "Recent activity and updates" },
  };
  const { title, sub } = titles[page] || titles.dashboard;

  return (
    <header className="header">
      <div className="header-left">
        <div>
          <div className="page-title">{title}</div>
          <div className="page-subtitle">{sub}</div>
        </div>
      </div>
      <div className="header-right">
        <a
          href="https://axosbank.com/Business/Fund-Finance"
          target="_blank"
          rel="noopener noreferrer"
          className="btn btn-ghost btn-sm"
        >
          <ExternalLink size={13} />
          Axos Fund Finance
        </a>
        <button className="btn btn-ghost btn-icon" onClick={() => onNav("alerts")} style={{ position: "relative" }}>
          <Bell size={16} />
          {unread > 0 && (
            <span style={{
              position: "absolute", top: 4, right: 4,
              width: 8, height: 8, borderRadius: "50%",
              background: "var(--red-500)", border: "2px solid var(--white)"
            }} />
          )}
        </button>
        <Avatar initials="BC" gold />
      </div>
    </header>
  );
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
function Dashboard({ onNav }) {
  const totalExposure = DEALS.reduce((sum, d) => {
    const n = parseFloat(d.amount.replace(/[$M]/g, "")) || 0;
    return sum + n;
  }, 0);

  const activity = [
    { text: "KKR Credit Partners VII advanced to Closing stage.", time: "2 hrs ago" },
    { text: "Dan Lynch sent a message regarding LP schedule review.", time: "5 hrs ago" },
    { text: "LP Schedule — Final uploaded and received by Axos.", time: "5 hrs ago" },
    { text: "Audited Financial Statements approved for Blackstone Credit Fund IV.", time: "2 days ago" },
    { text: "Apollo Capital Partners VIII term sheet issued by Axos team.", time: "3 days ago" },
  ];

  return (
    <div>
      <div className="section-header mb-24">
        <div>
          <div className="section-title">Portfolio Overview</div>
          <div className="section-sub">As of {new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</div>
        </div>
        <button className="btn btn-primary" onClick={() => onNav("deals")}>
          View All Deals <ChevronRight size={13} />
        </button>
      </div>

      <div className="kpi-grid">
        {[
          { label: "Total Exposure", value: `$${totalExposure.toFixed(0)}M`, sub: "Across 5 active facilities", accent: true },
          { label: "Active Deals", value: DEALS.length, sub: "In pipeline" },
          { label: "Pending Documents", value: DOCUMENTS.filter(d => d.status !== "Approved").length, sub: "Awaiting review" },
          { label: "Deals Closing", value: DEALS.filter(d => d.status === "Closing").length, sub: "In final stage" },
        ].map((k, i) => (
          <div key={i} className={`kpi-card${k.accent ? " kpi-accent" : ""}`}>
            <div className="kpi-label">{k.label}</div>
            <div className="kpi-value">{k.value}</div>
            <div className="kpi-sub">{k.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid-2 mb-24">
        <div className="card">
          <div className="card-header">
            <span className="card-title">Active Deal Pipeline</span>
            <button className="btn btn-ghost btn-sm" onClick={() => onNav("deals")}>View All</button>
          </div>
          <div style={{ padding: "0 22px" }}>
            {DEALS.map(deal => (
              <div key={deal.id} style={{ padding: "14px 0", borderBottom: "1px solid var(--slate-200)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600, color: "var(--navy-900)" }}>{deal.client}</div>
                    <div style={{ fontSize: 11, color: "var(--slate-500)" }}>{STAGES[deal.stage]}</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 13, fontWeight: 600, fontFamily: "var(--font-mono)", color: "var(--navy-900)" }}>{deal.amount}</div>
                    {statusBadge(deal.status)}
                  </div>
                </div>
                <div style={{ height: 4, background: "var(--slate-200)", borderRadius: 2 }}>
                  <div style={{
                    height: "100%",
                    width: `${((deal.stage + 1) / STAGES.length) * 100}%`,
                    background: deal.status === "Closing" ? "var(--gold-400)" : "var(--navy-800)",
                    borderRadius: 2,
                    transition: "width 0.6s ease"
                  }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <span className="card-title">Recent Activity</span>
            <span className="badge badge-green">Live</span>
          </div>
          <div className="card-body" style={{ padding: "0 22px" }}>
            {activity.map((a, i) => (
              <div key={i} className="activity-item">
                <div className="activity-dot" />
                <div>
                  <div className="activity-text">{a.text}</div>
                  <div className="activity-time">{a.time}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-header">
          <span className="card-title">Quick Actions</span>
        </div>
        <div className="card-body" style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
          <button className="btn btn-primary" onClick={() => onNav("documents")}>
            <UploadCloud size={14} /> Upload Document
          </button>
          <button className="btn btn-outline" onClick={() => onNav("messages")}>
            <MessageSquare size={14} /> Message Your Underwriter
          </button>
          <button className="btn btn-outline" onClick={() => onNav("team")}>
            <Users size={14} /> View Deal Team
          </button>
          <button className="btn btn-outline" onClick={() => onNav("history")}>
            <Clock size={14} /> Transaction History
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── DEALS ────────────────────────────────────────────────────────────────────
function Deals({ onNav }) {
  const [selected, setSelected] = useState(DEALS[0].id);
  const deal = DEALS.find(d => d.id === selected);

  return (
    <div style={{ display: "grid", gridTemplateColumns: "280px 1fr", gap: 20, height: "calc(100vh - 140px)" }}>
      <div className="card" style={{ overflow: "hidden", display: "flex", flexDirection: "column" }}>
        <div className="card-header">
          <span className="card-title">Active Deals</span>
          <Badge label={`${DEALS.length} deals`} variant="slate" />
        </div>
        <div style={{ overflowY: "auto", flex: 1 }}>
          {DEALS.map(d => (
            <div
              key={d.id}
              className={`deal-list-item${selected === d.id ? " selected" : ""}`}
              onClick={() => setSelected(d.id)}
            >
              <div style={{ fontSize: 13, fontWeight: 600, color: "var(--navy-900)", marginBottom: 2 }}>{d.client}</div>
              <div style={{ fontSize: 11, color: "var(--slate-500)", marginBottom: 6 }}>{d.type}</div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontFamily: "var(--font-mono)", fontSize: 12, fontWeight: 600 }}>{d.amount}</span>
                {statusBadge(d.status)}
              </div>
              <div style={{ fontSize: 10, color: "var(--slate-400)", marginTop: 4 }}>
                Stage: {STAGES[d.stage]}
              </div>
            </div>
          ))}
        </div>
      </div>

      {deal && (
        <div style={{ overflowY: "auto" }}>
          <div className="card mb-16">
            <div style={{ padding: "22px 24px", borderBottom: "1px solid var(--slate-200)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
                <div>
                  <div style={{ fontSize: 18, fontWeight: 700, color: "var(--navy-900)", marginBottom: 4 }}>{deal.dealName}</div>
                  <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                    {statusBadge(deal.status)}
                    {priorityBadge(deal.priority)}
                    <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--slate-500)" }}>Opened {deal.opened}</span>
                  </div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 24, fontWeight: 700, color: "var(--navy-900)", fontFamily: "var(--font-mono)" }}>{deal.amount}</div>
                  <div style={{ fontSize: 11, color: "var(--slate-500)" }}>Facility Size</div>
                </div>
              </div>
              <Pipeline stageIndex={deal.stage} />
            </div>
            <div style={{ padding: "18px 24px", display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 20 }}>
              {[
                { label: "Underwriter", value: deal.underwriter },
                { label: "Facility Type", value: deal.type },
                { label: "Credit Rating", value: deal.rating },
                { label: "LTV", value: deal.ltv || "—" },
              ].map((s, i) => (
                <div key={i}>
                  <div style={{ fontSize: 10, fontWeight: 600, letterSpacing: "0.10em", textTransform: "uppercase", color: "var(--slate-500)", marginBottom: 4 }}>{s.label}</div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: "var(--navy-900)" }}>{s.value}</div>
                </div>
              ))}
            </div>
            {deal.notes && (
              <div style={{ padding: "0 24px 18px" }}>
                <div style={{ background: "var(--surface)", border: "1px solid var(--slate-200)", borderRadius: "var(--radius-md)", padding: "12px 14px", fontSize: 12, color: "var(--slate-600)", lineHeight: 1.55 }}>
                  <strong style={{ color: "var(--navy-900)" }}>Status Note:</strong> {deal.notes}
                </div>
              </div>
            )}
            <div style={{ padding: "14px 24px", borderTop: "1px solid var(--slate-200)", display: "flex", gap: 10 }}>
              <button className="btn btn-primary" onClick={() => onNav("messages")}>
                <MessageSquare size={13} /> Message Underwriter
              </button>
              <button className="btn btn-outline" onClick={() => onNav("documents")}>
                <UploadCloud size={13} /> Upload Document
              </button>
            </div>
          </div>

          <div className="card">
            <div className="card-header">
              <span className="card-title">Documents for This Deal</span>
              <button className="btn btn-outline btn-sm" onClick={() => onNav("documents")}>View All</button>
            </div>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Document</th>
                    <th>Stage</th>
                    <th>Uploaded</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {DOCUMENTS.filter(d => d.dealId === deal.id).length === 0 ? (
                    <tr><td colSpan={4} style={{ textAlign: "center", color: "var(--slate-400)", padding: 32 }}>No documents yet for this deal.</td></tr>
                  ) : (
                    DOCUMENTS.filter(d => d.dealId === deal.id).map(doc => (
                      <tr key={doc.id}>
                        <td>
                          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                            <FileText size={14} color="var(--slate-500)" />
                            <div>
                              <div style={{ fontWeight: 500 }}>{doc.name}</div>
                              <div style={{ fontSize: 10, color: "var(--slate-400)", fontFamily: "var(--font-mono)" }}>{doc.type} · {doc.size}</div>
                            </div>
                          </div>
                        </td>
                        <td><Badge label={doc.stage} variant="slate" /></td>
                        <td><span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>{doc.uploaded}</span></td>
                        <td>{statusBadge(doc.status)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── DOCUMENTS ────────────────────────────────────────────────────────────────
function Documents() {
  const [drag, setDrag] = useState(false);
  const [uploads, setUploads] = useState([]);
  const fileRef = useRef();

  function handleFiles(files) {
    const newUploads = Array.from(files).map(f => ({
      id: Date.now() + Math.random(),
      name: f.name,
      size: `${(f.size / 1024 / 1024).toFixed(1)} MB`,
      type: f.name.split(".").pop().toUpperCase(),
      stage: "Due Diligence",
      uploaded: new Date().toISOString().split("T")[0],
      status: "Pending Review",
      uploadedBy: "Client",
      dealId: "d1",
    }));
    setUploads(prev => [...prev, ...newUploads]);
  }

  const allDocs = [...DOCUMENTS, ...uploads];

  return (
    <div>
      <div className="section-header mb-24">
        <div>
          <div className="section-title">Document Vault</div>
          <div className="section-sub">All uploads are encrypted at rest and in transit.</div>
        </div>
      </div>

      <div
        className={`upload-zone mb-24${drag ? " drag-over" : ""}`}
        onClick={() => fileRef.current.click()}
        onDragOver={e => { e.preventDefault(); setDrag(true); }}
        onDragLeave={() => setDrag(false)}
        onDrop={e => { e.preventDefault(); setDrag(false); handleFiles(e.dataTransfer.files); }}
      >
        <div className="upload-icon">
          <UploadCloud size={20} color="var(--white)" />
        </div>
        <div className="upload-title">Drag and drop files to upload securely</div>
        <div className="upload-sub">PDF, Excel, Word · Maximum 50 MB per file</div>
        <div style={{ marginTop: 14 }}>
          <span className="btn btn-primary btn-sm">Select Files</span>
        </div>
        <input
          ref={fileRef}
          type="file"
          multiple
          style={{ display: "none" }}
          onChange={e => handleFiles(e.target.files)}
        />
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
        <Shield size={14} color="var(--green-500)" />
        <span style={{ fontSize: 11, color: "var(--slate-500)" }}>
          All documents are encrypted at rest using AES-256 and accessible only to your Axos deal team.
        </span>
      </div>

      <div className="card">
        <div className="card-header">
          <span className="card-title">All Documents</span>
          <Badge label={`${allDocs.length} files`} variant="slate" />
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Document Name</th>
                <th>Deal</th>
                <th>Stage</th>
                <th>Date</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {allDocs.map(doc => (
                <tr key={doc.id}>
                  <td>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <FileText size={14} color="var(--slate-500)" />
                      <div>
                        <div style={{ fontWeight: 500 }}>{doc.name}</div>
                        <div style={{ fontSize: 10, color: "var(--slate-400)", fontFamily: "var(--font-mono)" }}>{doc.type} · {doc.size}</div>
                      </div>
                    </div>
                  </td>
                  <td style={{ fontSize: 12, color: "var(--slate-600)" }}>
                    {DEALS.find(d => d.id === doc.dealId)?.client || "—"}
                  </td>
                  <td><Badge label={doc.stage} variant="slate" /></td>
                  <td><span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>{doc.uploaded}</span></td>
                  <td>{statusBadge(doc.status)}</td>
                  <td>
                    <div style={{ display: "flex", gap: 4 }}>
                      <button className="btn btn-ghost btn-sm btn-icon"><Eye size={13} /></button>
                      <button className="btn btn-ghost btn-sm btn-icon"><Download size={13} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ─── MESSAGES ─────────────────────────────────────────────────────────────────
function Messages() {
  const [activeThread, setActiveThread] = useState(MESSAGES[0].id);
  const [drafts, setDrafts] = useState({});
  const [threads, setThreads] = useState(MESSAGES);

  const thread = threads.find(t => t.id === activeThread);
  const deal = DEALS.find(d => d.id === thread?.dealId);

  function sendMessage() {
    const text = drafts[activeThread]?.trim();
    if (!text) return;
    setThreads(prev => prev.map(t =>
      t.id === activeThread
        ? { ...t, thread: [...t.thread, { from: "You", role: deal?.client || "Client", text, time: new Date().toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }), date: "Today", isAxos: false }] }
        : t
    ));
    setDrafts(prev => ({ ...prev, [activeThread]: "" }));
  }

  return (
    <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: 20, height: "calc(100vh - 140px)" }}>
      <div className="card" style={{ overflow: "hidden", display: "flex", flexDirection: "column" }}>
        <div className="card-header">
          <span className="card-title">Conversations</span>
        </div>
        {threads.map(t => {
          const d = DEALS.find(x => x.id === t.dealId);
          const uw = TEAM.find(m => m.id === d?.uwId);
          const last = t.thread[t.thread.length - 1];
          return (
            <div
              key={t.id}
              className={`deal-list-item${activeThread === t.id ? " selected" : ""}`}
              onClick={() => setActiveThread(t.id)}
            >
              <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                <Avatar initials={uw?.avatar || "AX"} online={uw?.online} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: "var(--navy-900)" }}>{uw?.name}</div>
                  <div style={{ fontSize: 11, color: "var(--slate-500)", marginBottom: 4 }}>{d?.client}</div>
                  <div style={{ fontSize: 11, color: "var(--slate-400)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {last?.text}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {thread && deal && (
        <div className="card" style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
          <div className="card-header" style={{ flexShrink: 0 }}>
            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <Avatar initials={TEAM.find(m => m.id === deal.uwId)?.avatar || "AX"} online />
              <div>
                <div className="card-title">{TEAM.find(m => m.id === deal.uwId)?.name}</div>
                <div style={{ fontSize: 11, color: "var(--slate-500)" }}>{deal.dealName} · {deal.type}</div>
              </div>
            </div>
            <Badge label={`Stage: ${STAGES[deal.stage]}`} variant="blue" />
          </div>

          <div style={{ flex: 1, overflowY: "auto", padding: "20px 22px" }}>
            {thread.thread.map((msg, i) => (
              <div key={i} className={`message-row${msg.isAxos ? "" : " client"}`}>
                {msg.isAxos && <Avatar initials={TEAM.find(m => m.name === msg.from)?.avatar || "AX"} size="sm" />}
                <div>
                  <div style={{ fontSize: 10, color: "var(--slate-400)", marginBottom: 4, fontFamily: "var(--font-mono)" }}>
                    {msg.from} · {msg.date} {msg.time}
                  </div>
                  <div className={`message-bubble${msg.isAxos ? " message-axos" : " message-client"}`}>{msg.text}</div>
                </div>
              </div>
            ))}
          </div>

          <div style={{ borderTop: "1px solid var(--slate-200)", padding: "14px 20px", display: "flex", gap: 10, flexShrink: 0 }}>
            <input
              className="form-input"
              placeholder="Compose a message to your underwriter…"
              value={drafts[activeThread] || ""}
              onChange={e => setDrafts(prev => ({ ...prev, [activeThread]: e.target.value }))}
              onKeyDown={e => e.key === "Enter" && !e.shiftKey && sendMessage()}
            />
            <button className="btn btn-primary btn-icon" onClick={sendMessage}>
              <Send size={14} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── TEAM ─────────────────────────────────────────────────────────────────────
function Team() {
  const depts = ["Leadership", "Relationship Management", "Underwriting", "Associates"];

  return (
    <div>
      <div className="section-header mb-24">
        <div>
          <div className="section-title">Axos Fund Finance Team</div>
          <div className="section-sub">New York, NY · For direct inquiries, contact your Relationship Manager.</div>
        </div>
      </div>
      {depts.map(dept => {
        const members = TEAM.filter(m => m.dept === dept);
        return (
          <div key={dept} style={{ marginBottom: 28 }}>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--slate-500)", marginBottom: 14, paddingBottom: 8, borderBottom: "1px solid var(--slate-200)" }}>
              {dept}
            </div>
            <div className="team-grid">
              {members.map(m => {
                const assignedDeal = DEALS.find(d => d.uwId === m.id);
                return (
                  <div key={m.id} className="team-card">
                    <div className="team-card-header">
                      <Avatar initials={m.avatar} online={m.online} size="lg" gold={m.dept === "Leadership"} />
                      <div>
                        <div className="team-name">{m.name}</div>
                        <div className="team-title">{m.title}</div>
                        {m.specialty && <div style={{ fontSize: 10, color: "var(--gold-500)", marginTop: 2, fontWeight: 500 }}>{m.specialty}</div>}
                      </div>
                    </div>
                    {assignedDeal && (
                      <div style={{ background: "var(--surface)", borderRadius: "var(--radius-md)", padding: "8px 10px", marginBottom: 12, fontSize: 11, color: "var(--slate-600)" }}>
                        <div style={{ fontWeight: 600, color: "var(--navy-900)" }}>{assignedDeal.client}</div>
                        <div>{assignedDeal.type} · {STAGES[assignedDeal.stage]}</div>
                      </div>
                    )}
                    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                      <div style={{ fontSize: 12, color: "var(--slate-600)" }}>
                        <a href={`mailto:${m.email}`} style={{ color: "var(--blue-500)" }}>{m.email}</a>
                      </div>
                      <div style={{ fontSize: 12, color: "var(--slate-600)" }}>{m.phone}</div>
                    </div>
                    <div style={{ marginTop: 12, display: "flex", gap: 8 }}>
                      <a href={`mailto:${m.email}`} className="btn btn-outline btn-sm" style={{ flex: 1, justifyContent: "center" }}>Email</a>
                      <span style={{ fontSize: 11, alignSelf: "center", color: m.online ? "var(--green-500)" : "var(--slate-400)", fontWeight: 500 }}>
                        {m.online ? "● Online" : "● Away"}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── HISTORY ──────────────────────────────────────────────────────────────────
function History() {
  const [expanded, setExpanded] = useState(null);

  return (
    <div>
      <div className="section-header mb-24">
        <div>
          <div className="section-title">Transaction History</div>
          <div className="section-sub">All prior closed transactions for your organization.</div>
        </div>
      </div>
      <div className="card">
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Deal Name</th>
                <th>Client</th>
                <th>Amount</th>
                <th>Underwriter</th>
                <th>Closed</th>
                <th>IRR</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {DEAL_HISTORY.map(deal => (
                <tr key={deal.id} style={{ cursor: "pointer" }} onClick={() => setExpanded(expanded === deal.id ? null : deal.id)}>
                  <td>
                    <div style={{ fontWeight: 500 }}>{deal.dealName}</div>
                    <div style={{ fontSize: 11, color: "var(--slate-400)" }}>{deal.type}</div>
                  </td>
                  <td>{deal.client}</td>
                  <td style={{ fontFamily: "var(--font-mono)", fontWeight: 600 }}>{deal.amount}</td>
                  <td>{deal.underwriter}</td>
                  <td style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>{deal.closed}</td>
                  <td style={{ fontFamily: "var(--font-mono)", fontWeight: 600, color: "var(--green-500)" }}>{deal.irr}</td>
                  <td>{statusBadge(deal.status)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <div style={{ marginTop: 20, textAlign: "center", fontSize: 12, color: "var(--slate-400)" }}>
        All historical transaction records are retained per Axos Bank regulatory requirements.
      </div>
    </div>
  );
}

// ─── ALERTS ───────────────────────────────────────────────────────────────────
function Alerts({ notifications, onRead }) {
  const icons = { stage: TrendingUp, document: FileText, message: MessageSquare };

  return (
    <div>
      <div className="section-header mb-24">
        <div>
          <div className="section-title">Alerts & Notifications</div>
        </div>
        <button className="btn btn-outline" onClick={() => onRead("all")}>Mark All Read</button>
      </div>
      <div className="card">
        {notifications.map(n => {
          const Icon = icons[n.type] || Bell;
          return (
            <div key={n.id} className={`notif-item${!n.read ? " unread" : ""}`} onClick={() => onRead(n.id)}>
              <div style={{ width: 34, height: 34, borderRadius: "var(--radius-md)", background: n.read ? "var(--slate-200)" : "var(--blue-100)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <Icon size={14} color={n.read ? "var(--slate-500)" : "var(--blue-500)"} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: n.read ? 500 : 600, color: "var(--navy-900)", marginBottom: 2 }}>{n.title}</div>
                <div style={{ fontSize: 12, color: "var(--slate-600)" }}>{n.body}</div>
                <div style={{ fontSize: 10, color: "var(--slate-400)", marginTop: 4, fontFamily: "var(--font-mono)" }}>{n.time}</div>
              </div>
              {!n.read && <div className="notif-dot" />}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── ROOT ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState("dashboard");
  const [notifications, setNotifications] = useState(NOTIFICATIONS);

  const unread = notifications.filter(n => !n.read).length;

  function markRead(id) {
    if (id === "all") {
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    } else {
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
    }
  }

  const pages = {
    dashboard: <Dashboard onNav={setPage} />,
    deals:     <Deals onNav={setPage} />,
    documents: <Documents />,
    messages:  <Messages />,
    team:      <Team />,
    history:   <History />,
    alerts:    <Alerts notifications={notifications} onRead={markRead} />,
  };

  return (
    <div className="app-shell">
      <Ticker />
      <Sidebar active={page} onNav={setPage} unread={unread} />
      <Header page={page} unread={unread} onNav={setPage} />
      <main className="main-content">
        {pages[page]}
      </main>
    </div>
  );
}
