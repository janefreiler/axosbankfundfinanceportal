# Axos Bank Fund Finance — Client Portal

A production-ready React application for private credit clients.

## What's Included

- **Dashboard** — KPI cards, live deal progress bars, activity feed
- **Active Deals** — Full 7-stage pipeline with detail view, underwriter assignment, notes
- **Document Vault** — Drag-and-drop upload, status tracking (Approved / Pending / Under Review)
- **Messages** — Per-deal conversation threads with your assigned underwriter
- **Team & Contacts** — Full Axos Fund Finance NYC team with contact info
- **Deal History** — Archive of all prior closed transactions
- **Alerts** — Real-time notifications for stage changes, documents, messages
- **Live Ticker** — Scrolling deal status bar at top of page

## Setup (3 minutes)

### Prerequisites
- Node.js 16+ installed (download at nodejs.org)

### Steps

```bash
# 1. Navigate to this folder
cd axos-fund-finance-portal

# 2. Install dependencies
npm install

# 3. Start the development server
npm start
```

The portal opens at **http://localhost:3000**

---

## Deploy for Free (Netlify)

```bash
# Build the production version
npm run build
```

Then drag the `build/` folder to **netlify.com/drop** — you'll get a live URL instantly.

---

## File Structure

```
src/
  App.js              — All pages and components
  data/index.js       — Team members, deals, documents, messages
  styles/global.css   — Design tokens and all CSS
  index.js            — Entry point
public/
  index.html          — HTML shell
```

## Customization

- **Team members**: Edit `src/data/index.js` → `TEAM` array
- **Deals**: Edit `src/data/index.js` → `DEALS` array
- **Colors**: Edit `src/styles/global.css` → `:root` variables
- **Stages**: Edit `src/data/index.js` → `STAGES` array

---

*Axos Bank Fund Finance · New York, NY*  
*axosbank.com/Business/Fund-Finance*
